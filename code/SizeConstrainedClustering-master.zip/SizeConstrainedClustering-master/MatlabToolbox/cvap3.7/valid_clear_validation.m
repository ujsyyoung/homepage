
handles.ialg = [];
handles.ialgvalue = [];
handles.indexname = [];
handles.indexvalue = [];
handles.validstate = [];
guidata(hObject,handles);