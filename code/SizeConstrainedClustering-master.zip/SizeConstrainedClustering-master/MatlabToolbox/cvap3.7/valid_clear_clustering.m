
%handles.NC = [];
handles.runstate = [];
handles.labels = [];
handles.Cmerge = [];
handles.Dmatrix = [];
handles.algcluster = [];
guidata(hObject,handles);
set(handles.Loadsolution, 'Checked', 'off');