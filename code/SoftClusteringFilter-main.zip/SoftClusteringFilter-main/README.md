# SoftClusteringFilter
The implementation of "Edge-preserving Image Filtering Based on Soft Clustering" modified from SLIC.
