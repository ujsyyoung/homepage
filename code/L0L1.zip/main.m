% Choosing input files
image = imread('img.jpg');
lambda = 0.01;%[0.001, 0.1],0.01 by default��smoothing degree
kappa = 2;%(1, 2] iteration

I = im2double(image);

smoothing = L0_Smooth(I, lambda, kappa);

figure;
imshow([I, smoothing]);
