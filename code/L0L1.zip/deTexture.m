image = imread('texture.png');
lambda = 0.01;%[0.01, 0.1],0.01 by default��smoothing degree
kappa = 1.2;%(1, 2] iteration
n = 2;

I = im2double(image);
smoothing = I;

for i = 1: n
    smoothing = L0_Smooth_GPU(smoothing, lambda, lambda, kappa, 'texture');
end

figure;
imshow([I, smoothing]);