%   Distribution code Version 1.0 -- 09/23/2011 by Jiaya Jia Copyright 2011, The Chinese University of Hong Kong.
%
%   The Code is created based on the method described in the following paper 
%   [1] "Image Smoothing via L0 Gradient Minimization", Li Xu, Cewu Lu, Yi Xu, Jiaya Jia, ACM Transactions on Graphics, 
%   (SIGGRAPH Asia 2011), 2011. 
%  
%   The code and the algorithm are for non-comercial use only.


function S = L0_Smooth(Im, lambda, beta, kappa, flag)
%L0Smooth - Image Smoothing via L0 Gradient Minimization
%   S = L0Smooth(Im, lambda, kappa) performs L0 graidient smoothing of input
%   image Im, with smoothness weight lambda and rate kappa.
%
%   Paras: 
%   @Im    : Input UINT8 image, both grayscale and color images are acceptable.
%   @lambda: Smoothing parameter controlling the degree of smooth. (See [1]) 
%            Typically it is within the range [1e-3, 1e-1], 2e-2 by default.
%   @kappa : Parameter that controls the rate. (See [1])
%            Small kappa results in more iteratioins and with sharper edges.   
%            We select kappa in (1, 2].    
%            kappa = 2 is suggested for natural images.  
%
%   Example
%   ==========
%   Im  = imread('pflower.jpg');
%   S  = L0Smooth(Im); % Default Parameters (lambda = 1e-2, kappa = 2)
%   figure, imshow(Im), figure, imshow(S);


if ~exist('kappa','var')
    kappa = 2.0;
end
if ~exist('lambda','var')
    lambda = 1e-2;
end
if ~exist('beta','var')
    beta = 2*lambda;
end
if ~exist('flag','var')
    L1_MAX_ITER = 6;
else
    L1_MAX_ITER = 15;
end
% ------------------------------------------------------------------------------
% Global constants and defaults
% MAX_ITER: L2��������
MAX_ITER = 4;
rho = 50.0;
alpha = 1.5;
% Data preprocessing
S = im2double(Im);
[row, col, cha] = size(S);

count = 0; 

fx = [1, -1];
fy = [1; -1];
sizeI2D = [row,col];
otfFx = psf2otf(fx,sizeI2D); %�Ե���ɢ��������fx���п��ٸ���Ҷ�任���õ���ѧת����������otf
otfFy = psf2otf(fy,sizeI2D);
Normin = fft2(S);
Denormin1 = abs(otfFx) .^ 2 + abs(otfFy ) .^ 2;
if cha > 1
    Denormin1 = repmat(Denormin1, [1,1,cha]);
end
Denormin = 1 + rho/2 * Denormin1;

while count < L1_MAX_ITER
    w = beta/rho;
    % h-v subproblem
    h_input = [diff(S,1,2), S(:,1,:) - S(:,end,:)];
    v_input = [diff(S,1,1); S(1,:,:) - S(end,:,:)];
    if cha==1
        t = abs(h_input)+ abs(v_input)<lambda/beta;
    else
        t = sum((abs(h_input)+ abs(v_input)),3)<lambda/beta;
        t = repmat(t,[1,1,cha]);
    end
    h_input(t)=0; v_input(t)=0;
    % S subproblem

    % ADMM solver
    x = zeros(row, col, cha);
    z1 = zeros(row, col, cha);
    z2 = zeros(row, col, cha);
    u1 = zeros(row, col, cha);
    u2 = zeros(row, col, cha);
    for k = 1:MAX_ITER

        % S-update
        h = h_input + z1 - u1;
        v = v_input + z2 - u2;
        Normin1 = [h(:,end,:) - h(:, 1,:), -diff(h,1,2)];
        Normin2 = Normin1 + [v(end,:,:) - v(1, :,:); -diff(v,1,1)];
        FS = (Normin + rho/2 * fft2(Normin2)) ./ Denormin;
        x = real(ifft2(FS)); 

        % z-update
        if k < MAX_ITER
            h1 = [diff(x,1,2), x(:,1,:) - x(:,end,:)];
            v1 = [diff(x,1,1); x(1,:,:) - x(end,:,:)];
            Ax_hat1 = alpha * (h1 - h_input)+ (1-alpha) * z1 + u1 ;
            Ax_hat2 = alpha * (v1 - v_input) +(1-alpha) * z2 + u2;
            z1 = max(abs(Ax_hat1)-w,0).*sign(Ax_hat1);
            z2 = max(abs(Ax_hat2)-w,0).*sign(Ax_hat2);

            % u-update
            u1 = Ax_hat1 - z1;
            u2 = Ax_hat2 - z2;
        end

    end
    S = x;
    
    beta = beta*kappa;
    fprintf('.');
    count = count + 1;

end

fprintf('\n');
end

