function x = total_variation1(S, h_input, v_input, beta)
%% Global constants and defaults
MAX_ITER = 5;
rho = 50.0;
alpha = 1.5;
%% Data preprocessing
S = im2double(S);
[row, col, cha] = size(S);
w = beta/rho;

%% ADMM solver
x = zeros(row, col, cha);
z1 = zeros(row, col, cha);
z2 = zeros(row, col, cha);
u1 = zeros(row, col, cha);
u2 = zeros(row, col, cha);

fx = [1, -1];
fy = [1; -1];
sizeI2D = [row,col];
otfFx = psf2otf(fx,sizeI2D); %�Ե���ɢ��������fx���п��ٸ���Ҷ�任���õ���ѧת����������otf
otfFy = psf2otf(fy,sizeI2D);
Normin = fft2(S);
Denormin1 = abs(otfFx) .^ 2 + abs(otfFy ) .^ 2;
if cha > 1
    Denormin1 = repmat(Denormin1, [1,1,cha]);
end
Denormin = 1 + rho/2 * Denormin1;

for k = 1:MAX_ITER

    % x-update
    h = h_input + z1 - u1;
    v = v_input + z2 - u2;
    Normin1 = [h(:,end,:) - h(:, 1,:), -diff(h,1,2)];
    Normin2 = Normin1 + [v(end,:,:) - v(1, :,:); -diff(v,1,1)];
    FS = (Normin + rho/2 * fft2(Normin2)) ./ Denormin;
    x = real(ifft2(FS)); 
    
    % z-update
    h1 = [diff(x,1,2), x(:,1,:) - x(:,end,:)];
    v1 = [diff(x,1,1); x(1,:,:) - x(end,:,:)];
    Ax_hat1 = alpha * (h1 - h_input)+ (1-alpha) * z1 + u1;
    Ax_hat2 = alpha * (v1 - v_input) +(1-alpha) * z2 + u2;
    z1 = max(abs(Ax_hat1)-w,0).*sign(Ax_hat1);
    z2 = max(abs(Ax_hat2)-w,0).*sign(Ax_hat2);

    % u-update
    u1 = Ax_hat1 - z1;
    u2 = Ax_hat2 - z2;

end
end
