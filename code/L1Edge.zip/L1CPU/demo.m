clear;
I = im2double(imread('C:\Users\DELL\Desktop\L1CPU\kodim01.png'));
beta = 0.5;
S = I;
tic
sigma = 0.3;
alpha1 = 2;

h_input = [diff(S,1,2), S(:,1,:) - S(:,end,:)];
v_input = [diff(S,1,1); S(1,:,:) - S(end,:,:)];

tt1 = (abs(h_input)>=sigma);
tt2 = (abs(v_input)>=sigma);

hh_input = h_input(tt1);
hv_input = v_input(tt2);

h_input = sign(h_input)*sigma.*(abs(h_input)/sigma).^alpha1;
v_input = sign(v_input)*sigma.*(abs(v_input)/sigma).^alpha1;

h_input(tt1) = hh_input;
v_input(tt2) = hv_input;

h_input(:, end, :) = S(:,1,:) - S(:,end,:);
v_input(end, :, :) = S(1,:,:) - S(end,:,:);

x = total_variation1(S, h_input, v_input, beta);
toc

figure;
imshow([I, x]); drawnow();
